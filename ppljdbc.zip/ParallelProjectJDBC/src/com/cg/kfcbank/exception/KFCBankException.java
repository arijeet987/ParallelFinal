package com.cg.kfcbank.exception;

public class KFCBankException extends Exception
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public KFCBankException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}

}
