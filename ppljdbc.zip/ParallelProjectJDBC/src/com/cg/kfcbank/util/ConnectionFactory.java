package com.cg.kfcbank.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.cg.kfcbank.exception.KFCBankException;



public class ConnectionFactory {

	private static ConnectionFactory sigtonObj;

	public static ConnectionFactory getSigtonObj() {

		if (sigtonObj == null)
			sigtonObj = new ConnectionFactory();

		return sigtonObj;

	}

	public Connection getConnection() throws KFCBankException{
		Connection con = null;
		
			String driver = "oracle.jdbc.driver.OracleDriver";
			String url = "jdbc:oracle:thin:@localhost:1521:XE";
			String user = "system";
			String pwd = "Capgemini123";
		
			try {
				
				Class.forName(driver);
				
			} 
			catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				throw new KFCBankException("driver problem!!!!!!!!!!!!!!");
			}
			try {
				con = DriverManager.getConnection(url, user, pwd);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				throw new KFCBankException("connection problem!!!!!!!!!!!!!!");
			}
			
			if(con == null)
				System.out.println("con is null....");
		
		return con;
	}

}
