package com.cg.kfcbank.ui;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Scanner;
import com.cg.kfcbank.bean.Bank;
import com.cg.kfcbank.exception.KFCBankException;
import com.cg.kfcbank.service.BankServiceImpl;
import com.cg.kfcbank.service.IBankService;

public class TestBank {

		public static void main(String[] args) throws ClassNotFoundException, SQLException, KFCBankException {
			
			IBankService bankservice=new BankServiceImpl();
			
			
				while(true) {
					System.out.println("WELCOME TO KFC BANK\n");
					System.out.println("Enter 1 to create Account\n");
					System.out.println("Enter 2  for Deposit\n");
					System.out.println("Enter 3  for Withdraw\n");
					System.out.println("Enter 4 for display Balance\n");
					System.out.println("Enter 5 for fund transfer\n");
					System.out.println("Enter 6 to show all account details\n");
					System.out.println("Enter 7 to print all tranaction\n");
					System.out.println("Enter 8 for exit");
					Scanner sc=new Scanner(System.in);
					String sw = sc.next();
					
				switch(sw)
				{
				case "1":

					
					System.out.println("Enter AccountHolder Name:");
					String name = sc.next();
					while (!bankservice.accHolderValidation(name))
					{
						System.out.println("Please enter valid name");
						name=sc.next();
					}
					System.out.println("Enter  Contact Number:");
					long contact=sc.nextLong();
					while(!bankservice.mobValidation(contact))
					{
						System.out.println("please enter again");
						contact=sc.nextLong();
					}
					
					System.out.println("enter balance:");
					double balance=sc.nextDouble();
					while(!bankservice.balanceValidation(balance))
					{
						System.out.println("please enter again");
						balance=sc.nextDouble();
						
					}
					
					System.out.println("Enter Current city:");
					String address=sc.next();
					
					System.out.println("enter Emailid:");
					String email=sc.next();
						while(!(bankservice.emailValidation(email)))
					{
						System.out.println("please enter again");
						 email=sc.next();
						
					}
					Bank bank =new Bank();
					bank.setAccHolderName(name);
					bank.setAddress(address);
					bank.setMobNum(contact);
					bank.setBalance(balance);
					bank.setEmail(email);
					long accno = bankservice.addCustomer(bank);
					System.out.println("Your Account details are successfully registered and your A/c no is" +accno);
					System.out.println("Welcome to KFC  bank");
					break;
					
					
				case "2":
					System.out.println("Enter A/c number:");
					long accnum=sc.nextLong();
					System.out.println("Enter ammount to be deposited:");
					double amount=sc.nextDouble();
					while(!bankservice.balanceValidation(amount))
					{
						System.out.println("please enter again");
						amount=sc.nextDouble();
						
					}
					try {
						if (bankservice.deposit(accnum, amount))
							System.out.println("Deposited successfully Done!!!");
						else
							System.out.println("Failed!!!");
					} catch (KFCBankException e) 
					{
						System.err.println(e.getMessage());
					}
					break;
				case "3":
					System.out.println("Enter A/c Number:");
					long accccno=sc.nextLong();
					System.out.println("Enter ammount to be deposited:");
					double amountt=sc.nextDouble();
					while(!bankservice.balanceValidation(amountt))
					{
						System.out.println("please enter again");
						amountt=sc.nextDouble();
						
					}
					try {
						if (bankservice.withdraw(accccno, amountt))
							System.out.println("Withdraw successfully Done!!!");
						else
							System.out.println("Failed in Transaction!!!");
					} catch (KFCBankException e) 
					{
						System.err.println(e.getMessage());
					}
					break;
			
					
				case "4":
					System.out.println("Enter A/c num:");
					long accountno = sc.nextInt();
					try {
						System.out.println("Your balance is: " + bankservice.showbalance(accountno));
					} 
					catch (KFCBankException e) 
					{
						// TODO Auto-generated catch block
						System.err.println(e.getMessage());
					}
					break;
					
				case "5":
					System.out.println("Enter Your A/c number:");
					long acccountno1 = sc.nextLong();
					
					System.out.println("Enter Ammount to be transfer:");
					double ammount=sc.nextDouble();
					while(!bankservice.balanceValidation(ammount))
					{
						System.out.println("please enter again");
						ammount = sc.nextDouble();
						
					}
					try 
					{
						
					System.out.println("Enter A/c no to whom you want to transfer:");
					long acccountno2 = sc.nextLong();
					
					if(bankservice.fundTransfer(acccountno1, acccountno2,ammount))
						System.out.println("Fund Transfer Successfully Done!!!");
					
					else System.out.println("failed!!!!");
				} 
				catch (KFCBankException e) 
				{
					// TODO Auto-generated catch block
					System.err.println(e.getMessage());
				}
				break;
					
				case "6":
					try {
					Bank bankdetails =bankservice.accountDetails();
					System.out.println("A/c details are:"+bankdetails);
					}
					catch(KFCBankException e) 
					{
						System.err.println(e.getMessage());

					}
					break;
				case "7":;
					System.out.println("Enter A/c no to Print All the transactions:");
					long acno = sc.nextLong();
					try {
						
						System.out.println(bankservice.printTransaction(acno));
					} 
					catch (KFCBankException e) 
					{
						
						System.err.println(e.getMessage());
					}
					break;
				case "8":
					System.out.println("Terminated!!!!");
					System.out.println("Good Byeeee!!!!");
					System.exit(0);
					break;
				default:
					System.out.println("Wrong choise!!!!");
				}

				}
				
		}

}


