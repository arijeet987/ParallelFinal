package com.cg.kfcbank.dao;

public interface QueryMapper {
	
	public static final String INSERT_QUERY="INSERT INTO bank VALUES(accnumber.nextval, ?, ?, ?, ?, ?)";
	public static final String SEQ_AccNo="SELECT accnumber.currval FROM dual";
	public static final String SELECT_QUERY="SELECT * FROM bank";
	public static final String SELECT_BALENCE_QUERY="SELECT balance FROM bank WHERE acnum=?";
	public static final String UPDATE_QUERY="UPDATE bank SET balance=? WHERE acnum=?";
	public static final String INSERT_TRANSACTION="INSERT INTO transactions VALUES(?, ?, ?, ?, ?)";
	public static final String SELECT_TRANSACTION="SELECT * FROM transactions WHERE acnum=?";

}
