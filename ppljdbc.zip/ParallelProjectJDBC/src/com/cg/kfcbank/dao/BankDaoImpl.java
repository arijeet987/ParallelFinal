package com.cg.kfcbank.dao;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.cg.kfcbank.bean.Bank;
import com.cg.kfcbank.bean.Transaction;
import com.cg.kfcbank.exception.KFCBankException;
import com.cg.kfcbank.util.ConnectionFactory;




public class BankDaoImpl implements IBankDao 
{


	Connection con = null;
	PreparedStatement ps = null;
	
	
	@Override
	public long addCustomer(Bank bank) throws KFCBankException
	{
		try {
			con = ConnectionFactory.getSigtonObj().getConnection();
		}
		catch(KFCBankException e)
		{
			throw new KFCBankException("Problem in connection!!");
		}
		long AccNum=0;
		try {
		ps = con.prepareStatement(QueryMapper.INSERT_QUERY);
		
		ps.setString(1, bank.getAccHolderName());
		ps.setString(2, bank.getAddress());
		ps.setLong(3, bank.getMobNum());
		ps.setDouble(4, bank.getBalance());
		ps.setString(5, bank.getEmail());
		
		ps.executeUpdate();
		
		ps = con.prepareStatement(QueryMapper.SEQ_AccNo);
		ResultSet rs = ps.executeQuery();
		rs.next();
		AccNum = rs.getLong(1);
		}
		catch(Exception e) {
			
			throw new KFCBankException("problem in query!!!" + e.getMessage());
		}
		finally {
			try {
				if (con != null)
					con.close();
				if (ps != null)
					ps.close();
			} catch (Exception e) {
				throw new KFCBankException("problem in connection closing!!!!");
			}
		}

		return AccNum;
		// TODO Auto-generated method stub
		
	}
	@Override
	public boolean deposit(long AccNum, double ammount) throws KFCBankException {
		
		ResultSet rs = null;
		double balance = 0;
		try {
			con = ConnectionFactory.getSigtonObj().getConnection();
		} catch (KFCBankException e) {
			// TODO Auto-generated catch block
			throw new KFCBankException("connection is not  stablished!!!");
		}
		try {
			ps = con.prepareStatement(QueryMapper.SELECT_BALENCE_QUERY);
			ps.setLong(1, AccNum);
			rs = ps.executeQuery();
			ps = con.prepareStatement(QueryMapper.UPDATE_QUERY);
			if (rs.next())
				balance = rs.getDouble(1) + ammount;
			else {
				con.close();
				ps.close();
				rs.close();
				throw new KFCBankException("Account number is not present!!!");
				
			}
			ps.setDouble(1, balance);
			ps.setLong(2, AccNum);
			ps.executeUpdate();
			
		} catch (Exception e) {
			throw new KFCBankException("couldn't execute query!!!");
		} finally {
			try {
				if (con != null)
					con.close();
				if (ps != null)
					ps.close();
				if (rs != null)
					rs.close();
			} catch (Exception e) {
				throw new KFCBankException("problem in connection closing!!!!");
			}
		}

		putTransaction(ammount, AccNum, "Credited", balance);
		return true;
	}
	
	
	@Override
	public double showbalance(long AccNum) throws KFCBankException {
		
		ResultSet rs = null;
		double balance;
		
		try
		{
			con = ConnectionFactory.getSigtonObj().getConnection();
			
		}
		catch (KFCBankException e) {
			// TODO Auto-generated catch block
			throw new KFCBankException("connection is not established!!!" +e.getMessage());
		}
		try
		{
			ps = con.prepareStatement(QueryMapper.SELECT_BALENCE_QUERY);
			ps.setLong(1, AccNum);
			rs = ps.executeQuery();
			rs.next();
			balance = rs.getDouble(1);
		}
		catch(SQLException e)
		{
			throw new KFCBankException("Account no is not found!!!");
		}
		finally {
			try {
				if (con != null)
					con.close();
				if (ps != null)
					ps.close();
				if (rs != null)
					rs.close();
			} catch (Exception e) {
				
				throw new KFCBankException("problem in Connection!!!!");
			}
		}
		// TODO Auto-generated method stub
		return balance;
	}
	@Override
	public boolean fundTransfer(long accno1, long accno2, double amount) throws KFCBankException {
		
		if(withdraw(accno1, amount) && deposit(accno2, amount))
			return true;
		
		return false;
	
	}
	@Override
	public boolean withdraw(long AccNum, double amount) throws KFCBankException 
	
	{
		
		ResultSet rs = null;
		try {
			con = ConnectionFactory.getSigtonObj().getConnection();
		} 
		catch (KFCBankException e) 
		{
			// TODO Auto-generated catch block
			throw new KFCBankException("connection is not established!!!" + e.getMessage());
		}
		try {
			ps = con.prepareStatement(QueryMapper.SELECT_BALENCE_QUERY);
			ps.setLong(1, AccNum);
			rs = ps.executeQuery();
			ps = con.prepareStatement(QueryMapper.UPDATE_QUERY);
			double balance;
			if (rs.next())
			
				balance = rs.getDouble(1) - amount;
			
			else {
				con.close();
				ps.close();
				rs.close();
				throw new KFCBankException("Account number is not present!!!");
			}
			
			ps.setDouble(1,balance);
			ps.setLong(2, AccNum);
			ps.executeUpdate();
			putTransaction(amount, AccNum, "Debited", balance);
			con.close();
			return true;
			
		} catch (Exception e) {
			
			throw new KFCBankException("couldn't execute query!!!" + e.getMessage());
		} 
		finally {
			
			try {
				if (con != null)
					con.close();
				if (ps != null)
					ps.close();
				if (rs != null)
					rs.close();
			} 
			catch (Exception e) 
			{
				throw new KFCBankException("problem in connection closing!!!!" +e.getMessage());
			}
			
		}
		
		// TODO Auto-generated method stub
	}
	void putTransaction(double amount, long AccNum, String msg, double balance) throws KFCBankException {

		try {
			con = ConnectionFactory.getSigtonObj().getConnection();
		} catch (KFCBankException e) {
			// TODO Auto-generated catch block
			throw new KFCBankException("connection couldn't be established!!!" +e.getMessage());
		}
		try {
			ps = con.prepareStatement(QueryMapper.INSERT_TRANSACTION);
			ps.setLong(1, AccNum);
			ps.setDouble(2, amount);
			ps.setString(3, msg);
			ps.setDate(4, Date.valueOf(java.time.LocalDate.now()));
			ps.setDouble(5, balance);

			ps.executeUpdate();
		} catch (Exception e) {
			
			throw new KFCBankException("problem in execute query!!!" +e.getMessage());
		} finally {
			try {
				if (con != null)
					con.close();
				if (ps != null)
					ps.close();
			} catch (Exception e) {
				
				throw new KFCBankException("problem in Connection closing!!!!" + e.getMessage());
			}
		}
	}
	@Override
	public Bank accountDetails() throws KFCBankException {
	
		Bank bank = new Bank();
		try {
			con = ConnectionFactory.getSigtonObj().getConnection();
		}
		catch(KFCBankException e)
		{
			throw new KFCBankException("Connection is not  established!!" +e.getMessage());
		}
		try
		{
			ps = con.prepareStatement(QueryMapper.SELECT_QUERY);
			ResultSet rs = ps.executeQuery();
			
			rs.next();
			bank.setAcNum(rs.getLong(1));
			bank.setAccHolderName(rs.getString(2));
			bank.setAddress(rs.getString(3));
			bank.setMobNum(rs.getLong(4));
			bank.setBalance(rs.getDouble(5));
			bank.setEmail(rs.getString(6));
			
		}
 catch(Exception e) {
			
			throw new KFCBankException("problem in query!!!" + e.getMessage());
		}
		finally {
			try {
				if (con != null)
					con.close();
				if (ps != null)
					ps.close();
			} catch (Exception e) 
			{
				throw new KFCBankException("problem in connection closing!!!!" +e.getMessage());
			}
		}

		return bank;
		// TODO Auto-generated method stub
		
	}
	@Override
	public List<Transaction> printTransaction(long AccNo) throws KFCBankException {

		try {
			con = ConnectionFactory.getSigtonObj().getConnection();
		} catch (KFCBankException e) {
			// TODO Auto-generated catch block
			throw new KFCBankException("connection is not established!!!" +e.getMessage());
		}
		try {
			ps = con.prepareStatement(QueryMapper.SELECT_TRANSACTION);
			ps.setLong(1, AccNo);
			ResultSet rs = ps.executeQuery();
			List<Transaction> trainsactions = new ArrayList<Transaction>();
			while (rs.next()) {
				Transaction transaction = new Transaction();
				transaction.setDate(rs.getDate(4).toLocalDate());
				transaction.setAmount(rs.getDouble(2));
				transaction.setType(rs.getString(3));
				transaction.setBalance(rs.getDouble(5));
				trainsactions.add(transaction);
			}
			return trainsactions;
		} 
		catch (Exception e) {
			
			throw new KFCBankException("problem in Execute Query!!!" +e.getMessage());
		} finally {
			try {
				if (con != null)
					con.close();
				if (ps != null)
					ps.close();
			} catch (Exception e) 
			{
				
				throw new KFCBankException("problem in connection closing!!!!" +e.getMessage());
			}
		}
	}

	@Override
	public long displayDetails(Long AccNo) {
		// TODO Auto-generated method stub
		return 0;
	}
	
	
	

}
