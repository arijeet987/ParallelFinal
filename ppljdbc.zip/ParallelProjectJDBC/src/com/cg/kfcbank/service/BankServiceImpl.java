package com.cg.kfcbank.service;
import java.util.List;
import com.cg.kfcbank.bean.Bank;
import com.cg.kfcbank.bean.Transaction;
import com.cg.kfcbank.dao.BankDaoImpl;
import com.cg.kfcbank.dao.IBankDao;
import com.cg.kfcbank.exception.KFCBankException;

public class BankServiceImpl implements IBankService 
{
	IBankDao bankdao = new BankDaoImpl();

	@Override
	public long addCustomer(Bank bank) throws KFCBankException {
		
		return bankdao.addCustomer(bank);
	}

	@Override
	public boolean deposit(long AccNum, double ammount) throws KFCBankException {
		// TODO Auto-generated method stub
		return bankdao.deposit(AccNum, ammount);
	}

	@Override
	public double showbalance(long AccNum) throws KFCBankException {
		// TODO Auto-generated method stub
		return bankdao.showbalance(AccNum);
	}

	@Override
	public boolean fundTransfer(long accno1, long accno2, double amount) throws KFCBankException {
		// TODO Auto-generated method stub
		return bankdao.fundTransfer(accno1, accno2, amount);
	}

	@Override
	public boolean withdraw(long AccNum, double ammount) throws KFCBankException {
		// TODO Auto-generated method stub
		return bankdao.withdraw(AccNum, ammount);
	}

	@Override
	public Bank accountDetails() throws KFCBankException {
		
		return bankdao.accountDetails();
		
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Transaction> printTransaction(long AccNo) throws KFCBankException {
	
		return bankdao.printTransaction(AccNo);
	}

	@Override
	public boolean emailValidation(String email) {
		
		String regex = "[a-zA-Z0-9]+[@][a-zA-Z0-9]+([.][a-zA-Z]+)+";
		return email.matches(regex);
		// TODO Auto-generated method stub
	}

	@Override
	public boolean mobValidation(long contact) {
		// TODO Auto-generated method stub
		String regex = "(91|0)?[6-9][0-9]{9}";
		String phone = Long.toString(contact);
		return phone.matches(regex);
	}

	@Override
	public boolean accHolderValidation(String accHolder) {
		// TODO Auto-generated method stub
		String regex = "[A-Z][a-z]{3,15}";
		if(accHolder == null)
			return false;
		
		return accHolder.matches(regex);
	}
	@Override
	public boolean balanceValidation(double balance) {
		String regex = "[0-9]*\\.?[0-9]*";
		String bal = Double.toString(balance);
		return bal.matches(regex);
	}

	
	
	
}
