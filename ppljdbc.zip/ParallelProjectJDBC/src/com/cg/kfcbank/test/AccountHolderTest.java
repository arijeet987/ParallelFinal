package com.cg.kfcbank.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.cg.kfcbank.service.BankServiceImpl;
import com.cg.kfcbank.service.IBankService;

public class AccountHolderTest {
	
	IBankService bankservice = new BankServiceImpl();

	@Test
	public void testType1() {
		
		String name = "arijeet";
		assertFalse(bankservice.accHolderValidation(name));
	}
	
	@Test
	public void testType2() {

		String name = "Arijeet";
		assertTrue(bankservice.accHolderValidation(name));
	}
	
	@Test
	public void testType3() {

		String name = "Arijeet1";
		assertFalse(bankservice.accHolderValidation(name));
	}
	
	@Test
	public void testType4() 
	{
		String name = "123456";
		assertFalse(bankservice.accHolderValidation(name));
	}
	
	@Test
	public void testType5() {

		String name = "abc";
		assertFalse(bankservice.accHolderValidation(name));
	}
	
	@Test
	public void testType6() {

		String name = "abcdfdasdfcgdsjjfasdf";
		assertFalse(bankservice.accHolderValidation(name));
	}
	
	@Test
	public void testType7() {

		String name = null;
		assertFalse(bankservice.accHolderValidation(name));
	}

}
