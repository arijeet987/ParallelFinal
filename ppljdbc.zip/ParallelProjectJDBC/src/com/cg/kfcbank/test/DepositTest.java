package com.cg.kfcbank.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.cg.kfcbank.dao.BankDaoImpl;
import com.cg.kfcbank.dao.IBankDao;
import com.cg.kfcbank.exception.KFCBankException;

public class DepositTest {

	IBankDao bankdao = new BankDaoImpl();
	
	//exceptionTest
	@Test(expected=KFCBankException.class)
	public void test() throws KFCBankException {
		
		assertEquals(200, bankdao.deposit(10001, 500));
	}
	@Test
	public void test1() throws KFCBankException {
			assertEquals(2000, bankdao.deposit(10001, 500));
	}

}
