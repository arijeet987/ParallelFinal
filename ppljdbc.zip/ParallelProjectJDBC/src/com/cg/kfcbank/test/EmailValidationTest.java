package com.cg.kfcbank.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.cg.kfcbank.service.BankServiceImpl;
import com.cg.kfcbank.service.IBankService;

public class EmailValidationTest {
	
	IBankService bankservice = new BankServiceImpl();


	@Test
	public void mailType1() 
	{
		String email = "ari@gmail.com";						//right_way
		assertTrue(bankservice.emailValidation(email));
	}
	
	@Test 
	public void mailType2() {									//starts with number
		String email = "12@gmail.com";
		assertTrue(bankservice.emailValidation(email));
	}
	
	@Test 
	public void mailType3() {
		
		String email = "@gmail.com";							//before @ no letter or number
		assertFalse(bankservice.emailValidation(email));
	}
	
	@Test  
	public void mailType4() {
		
		String email = "arigmail.com";
		assertFalse(bankservice.emailValidation(email));		//no @ notation
	}
	
	@Test  
	public void mailType5() {
																	//no dot(.)
		String email = "ari@gmailcom";
		assertFalse(bankservice.emailValidation(email));
	}

}
