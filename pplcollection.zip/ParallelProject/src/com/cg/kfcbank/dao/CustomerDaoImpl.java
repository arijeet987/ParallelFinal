package com.cg.kfcbank.dao;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

import com.cg.kfcbank.bean.Customer;
import com.cg.kfcbank.bean.Transaction;
import com.cg.kfcbank.exception.BankException;
import com.cg.kfcbank.util.BankCollection;

public class CustomerDaoImpl implements ICustomerDao {


	@Override
	public int addCustomer(Customer customer) throws BankException 
	{
		if(customer.getName()==null)
		{
			throw new BankException("Name should not be null");
		}
		BankCollection.getCustomers().put(customer.getAccNum(), customer);
		return customer.getAccNum();
		
	}

	@Override
	public Customer displayDetails(int AccNum) {
		
		Customer customers=BankCollection.getCustomers().get(AccNum);
		return customers;


	}
	
	public boolean deposit(int AccNum, double amount) throws BankException
	{
		if(amount==0)
		{
			throw new BankException("amount should not be zerooo!!!!!!");
		}
		HashMap<Integer,Customer> customers = BankCollection.getCustomers();
		double balance=customers.get(AccNum).getBalance();
		Customer customer = customers.get(AccNum);
		if(customer==null)
		return false;
		
		customer.setBalance(balance + amount);
		
		Transaction transaction = new Transaction();
		transaction.setAmount(amount);
		transaction.setBalance(balance + amount);
		transaction.setDate(LocalDateTime.now());
		transaction.setType("Deposited");
		customers.get(AccNum).setTrans(transaction);
		return true;
		
		
	}

	@Override
	public boolean withdraw(int AccNum,double amount) {
		
		HashMap<Integer,Customer> customers= BankCollection.getCustomers();

		double balance=customers.get(AccNum).getBalance();
		Customer customer = customers.get(AccNum);
		if(customer==null)
			return false;
		
			customer.setBalance(balance-amount);
	
			
			Transaction transaction = new Transaction();
			transaction.setAmount(amount);
			transaction.setBalance(balance - amount);
			transaction.setDate(LocalDateTime.now());
			transaction.setType("Withdrawn");
			
			customers.get(AccNum).setTrans(transaction);
			return true;
		}

	@Override
	public double showbalance(int AccNum) {
		
		HashMap<Integer,Customer> customers = BankCollection.getCustomers();

		double balance = customers.get(AccNum).getBalance();
		
			return balance;
	}

	@Override
	public boolean fundTransfer(int accNum1, int accNum2, double amount) throws BankException 
	{
		if(withdraw(accNum1, amount) && deposit(accNum2, amount))
			return true;
		return false;
		
	}

	@Override
	public HashMap<Integer, Customer> accountDetails() {
		
	HashMap<Integer, Customer> customers = BankCollection.getCustomers();
		return customers;
		
	}

	@Override
	public ArrayList<Transaction> printTransaction(int AccNo) {
		
		
		ArrayList<Transaction> transactions = BankCollection.getCustomers().get(AccNo).getTrans();
		
		return transactions;
		
	}
		
		
	}


