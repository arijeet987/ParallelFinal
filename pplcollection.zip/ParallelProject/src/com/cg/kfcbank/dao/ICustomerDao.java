package com.cg.kfcbank.dao;

import java.util.ArrayList;
import java.util.HashMap;

import com.cg.kfcbank.bean.Customer;
import com.cg.kfcbank.bean.Transaction;
import com.cg.kfcbank.exception.BankException;

public interface ICustomerDao {
	
	
	public int addCustomer(Customer c) throws BankException;
	public Customer displayDetails(int AccNum);
	public boolean deposit(int AccNum,double amount) throws BankException;
	public double showbalance(int AccNum);
	public boolean fundTransfer(int accNum1,int accNum2,double amount) throws BankException;
	public boolean withdraw(int AccNum,double amount);
	public HashMap<Integer, Customer> accountDetails();
	public ArrayList<Transaction> printTransaction(int AccNo);
	

}
