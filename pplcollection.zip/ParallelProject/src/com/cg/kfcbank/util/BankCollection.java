package com.cg.kfcbank.util;

import java.util.HashMap;

import com.cg.kfcbank.bean.Customer;

public class BankCollection {
	
	private static HashMap<Integer,Customer> customers=new HashMap<>();

	public static HashMap<Integer, Customer> getCustomers() {
		return customers;
	}
	
	
}
