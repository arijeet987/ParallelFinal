package com.cg.kfcbank.bean;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;

public class Customer {
	
	private int AccNum;
	private String name;
	private long contact;
	private double balance;
	private String email;
	private LocalDateTime date;
	
	
	private ArrayList<Transaction> trans=new ArrayList<>();
	
	public LocalDateTime getDate() {
		return date;
	}
	public void setDate(LocalDateTime date) {
		this.date = date;
	}
	
	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getAccNum() {
		return AccNum;
	}
	public void setAccNum(int accNum) {
		AccNum = accNum;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getContact() {
		return contact;
	}
	public void setContact(long contact) {
		this.contact = contact;
		
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	
	public ArrayList<Transaction> getTrans() {
		return trans;
	}
	public void setTrans(Transaction trans) {
		this.trans.add(trans);
	}
	@Override
	public String toString() {
		return "Customer [AccNum=" + AccNum + ", name=" + name + ", contact=" + contact + ", balance=" + balance
				+ ", email=" + email + ", date=" + date + "]";
	}
	
	
}
