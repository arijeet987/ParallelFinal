package com.cg.kfcbank.service;

import java.util.ArrayList;
import java.util.HashMap;

import com.cg.kfcbank.bean.Customer;
import com.cg.kfcbank.bean.Transaction;
import com.cg.kfcbank.dao.CustomerDaoImpl;
import com.cg.kfcbank.dao.ICustomerDao;
import com.cg.kfcbank.exception.BankException;


public class CustomerServiceImpl implements ICustomerService {

	ICustomerDao customerdao=new CustomerDaoImpl();
	@Override
	public int addCustomer(Customer customer) throws BankException {
		
		return customerdao.addCustomer(customer);
		
		// TODO Auto-generated method stub
		
	}

	@Override
	public Customer displayDetails(int AccNum) {
		
		return customerdao.displayDetails(AccNum);
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean deposit(int AccNum,double amount) throws BankException {
		
		return customerdao.deposit(AccNum,amount);
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean withdraw(int AccNum,double amount) {
		
		return customerdao.withdraw(AccNum,amount);
		// TODO Auto-generated method stub
		
	}

	@Override
	public double showbalance(int AccNum) {
		
		return customerdao.showbalance(AccNum);
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean fundTransfer(int Accnum1, int AccNum2, double amount) throws BankException {
		
		return customerdao.fundTransfer(Accnum1, AccNum2, amount);
		
	}

	@Override
	public HashMap<Integer, Customer> accountdetails() {
		
		return customerdao.accountDetails();
		// TODO Auto-generated method stub
		
	}

	@Override
	public ArrayList<Transaction> printTransactions(int AccNum) {
		
		return customerdao.printTransaction(AccNum);
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean mailValidation(String mail) {
		
		String regex = "[a-zA-Z0-9]+[@][a-zA-Z0-9]+([.][a-zA-Z]+)+";
		return mail.matches(regex);
	}

	@Override
	public boolean mobValidation(long contact) {
				
		String regex = "(91|0)?[6-9][0-9]{9}";
		String mobile = Long.toString(contact);
		return mobile.matches(regex);
	}
	@Override
	public boolean accHolderValidation(String accHolder) {
		
		String regex = "[A-Z][a-z]{3,15}";
		if(accHolder == null)
			return false;
		
		return accHolder.matches(regex);
	}
	

	@Override
	public boolean balanceValidation(double balance) {

		String regex = "[0-9]*\\.?[0-9]*";
		String bal = Double.toString(balance);
		return bal.matches(regex);
		
	}

	

	

}
