package com.cg.kfcbank.service;

import java.util.ArrayList;
import java.util.HashMap;

import com.cg.kfcbank.bean.Customer;
import com.cg.kfcbank.bean.Transaction;
import com.cg.kfcbank.exception.BankException;

public interface ICustomerService {
	
	public int addCustomer(Customer customers) throws BankException;
	public double showbalance(int AccNum);
	public Customer displayDetails(int AccNum);
	public HashMap<Integer, Customer> accountdetails();
	public boolean fundTransfer(int AccNum1,int AccNum2,double amount) throws BankException;
	boolean withdraw(int AccNum, double amount);
	boolean deposit(int AccNum, double amount) throws BankException;
	public ArrayList<Transaction> printTransactions(int AccNum);
	
	boolean mailValidation (String email);
	boolean mobValidation(long contact);
	boolean accHolderValidation(String accHolder);
	boolean balanceValidation(double balance);

}
