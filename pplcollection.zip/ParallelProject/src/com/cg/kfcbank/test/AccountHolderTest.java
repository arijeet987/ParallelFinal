package com.cg.kfcbank.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.cg.kfcbank.service.CustomerServiceImpl;
import com.cg.kfcbank.service.ICustomerService;

public class AccountHolderTest {
	
ICustomerService service = new CustomerServiceImpl();
	
	@Test
	public void testType1() {
		
		String name = "arijeet";
		assertFalse(service.accHolderValidation(name));
	}
	
	@Test
	public void testType2() {

		String name = "Arijeet";
		assertTrue(service.accHolderValidation(name));
	}
	
	@Test
	public void testType3() {

		String name = "Arijeet1";
		assertFalse(service.accHolderValidation(name));
	}
	
	@Test
	public void testType4() 
	{
		String name = "123456";
		assertFalse(service.accHolderValidation(name));
	}
	
	@Test
	public void testType5() {

		String name = "abc";
		assertFalse(service.accHolderValidation(name));
	}
	
	@Test
	public void testType6() {

		String name = "abcdfdasdfcgdsjjfasdf";
		assertFalse(service.accHolderValidation(name));
	}
	
	@Test
	public void testType7() {

		String name = null;
		assertFalse(service.accHolderValidation(name));
	}

}
