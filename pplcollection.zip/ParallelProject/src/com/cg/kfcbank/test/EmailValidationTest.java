package com.cg.kfcbank.test;

import static org.junit.Assert.*;
import org.junit.Test;
import com.cg.kfcbank.dao.ICustomerDao;
import com.cg.kfcbank.service.CustomerServiceImpl;
import com.cg.kfcbank.service.ICustomerService;

public class EmailValidationTest {
	
 ICustomerService service = new CustomerServiceImpl();

	@Test
	public void mailType1() 
	{
		String email = "ari@gmail.com";						//right_way
		assertTrue(service.mailValidation(email));
	}
	
	@Test 
	public void mailType2() {									//starts with number
		String email = "12@gmail.com";
		assertTrue(service.mailValidation(email));
	}
	
	@Test 
	public void mailType3() {
		
		String email = "@gmail.com";							//before @ no letter or number
		assertFalse(service.mailValidation(email));
	}
	
	@Test  
	public void mailType4() {
		
		String email = "arigmail.com";
		assertFalse(service.mailValidation(email));		//no @ notation
	}
	
	@Test  
	public void mailType5() {
																	//no dot(.)
		String email = "ari@gmailcom";
		assertFalse(service.mailValidation(email));
	}

}
