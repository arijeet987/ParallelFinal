package com.cg.kfcbank.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.cg.kfcbank.dao.CustomerDaoImpl;
import com.cg.kfcbank.dao.ICustomerDao;
import com.cg.kfcbank.exception.BankException;

public class DepositTest {

	ICustomerDao cusdao = new CustomerDaoImpl();
	
	@Test 	(expected=BankException.class)
	public void test() throws BankException  {
		
		assertEquals(500, cusdao.deposit(85987,500));
	}
	@Test
	public void test1() throws BankException {
			assertEquals(2000, cusdao.deposit(10001, 500));
	}

}
