package com.cg.kfcbank.ui;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Random;
import java.util.Scanner;

import com.cg.kfcbank.bean.Customer;
import com.cg.kfcbank.exception.BankException;
import com.cg.kfcbank.service.CustomerServiceImpl;
import com.cg.kfcbank.service.ICustomerService;

public class KFCBank {
	
	public static void main(String[] args) throws BankException {
		
		ICustomerService customerservice = new CustomerServiceImpl();
		
			while(true) {
				
				System.out.println("Enter 1 to Create Account\n");
				System.out.println("Enter 2 Balance for Deposit\n");
				System.out.println("Enter 3 Balance for Withdraw\n");
				System.out.println("Enter 4 for Display Details\n");
				System.out.println("Enter 5 for Display Balance\n");
				System.out.println("Enter 6 for Fund Transfer\n");
				System.out.println("Enter 7 to Show All Account Details\n");
				System.out.println("Enter 8 to Print All Tranactions\n");
				System.out.println("Enter 9 for Exit ");

				Scanner sc=new Scanner(System.in);
				int sw = sc.nextInt();
				
			switch(sw)
			{
			case 1:
				Random random=new Random();
				int accNum=random.nextInt(200000);
				System.out.println("Enter Customer Name:");
				String name=sc.next();
 				while(!customerservice.accHolderValidation(name))
 				{
 					System.out.println("Enter Name Again");
 					name=sc.next();
 				}
 				
				System.out.println("Enter Customer Contact Number:");
				long contact=sc.nextLong();
				while(!customerservice.mobValidation(contact))
 				{
 					System.out.println("Enter Contact Again");
 					contact=sc.nextLong();
 				}
 				
				System.out.println("Enter opening Balance:");
				double balance=sc.nextDouble();
				while(!customerservice.balanceValidation(balance))
				{

 					System.out.println("Enter Balance Again");
 					balance=sc.nextDouble();
					
				}
				
 				System.out.println("Enter mail id:");
				String email = sc.next();
				while(!customerservice.mailValidation(email))
				{
					System.out.println("Enter mail id Again");
 					email = sc.next();
				
 				}
				Customer customer=new Customer();
				customer.setAccNum(accNum);
				customer.setName(name);
				customer.setContact(contact);
				customer.setBalance(balance);
				customer.setEmail(email);
				customer.setDate(LocalDateTime.now());
				int AccNo = customerservice.addCustomer(customer);
				System.out.println("welcome to KFC  bank");
				System.out.println("Your A/C number is..:"+AccNo);
				break;
			case 2:
				System.out.println("Enter A/c num:");
				int accnum=sc.nextInt();
				System.out.println("Enter ammount to deposit");
				double depositamount = sc.nextDouble();
				
				if(customerservice.deposit(accnum,depositamount))
				System.out.println("Deposite Successfully Done...");
				else
					System.out.println("Not Successfull!!!Please try again..");
				break;
			case 3:
				System.out.println("Enter your A/c num:");
				int AccNum = sc.nextInt();
				System.out.println("Enter ammount to withdraw");
				double withdrawamount=sc.nextDouble();
				if(customerservice.withdraw(AccNum,withdrawamount))
					System.out.println("Withdraw successfully Done....");
				break;
				
			case 4:
				System.out.println("Enter your A/c number to know Details");
				int accno = sc.nextInt();
				 System.out.println(customerservice.displayDetails(accno));
				break;
			case 5:
				System.out.println("Enter A/c number:");
				int  accountnumber = sc.nextInt();
				System.out.println("Your Balace is: "+customerservice.showbalance(accountnumber));
				break;
				
			case 6:
				System.out.println("Enter yor A/c number:");
				int AccountNum1 = sc.nextInt();
				System.out.println("Enter A/c no to whom you want to transfer:");
				int AccountNum2 = sc.nextInt();
				System.out.println("Enter ammount to be transfer:");
				double amount=sc.nextDouble();
				customerservice.fundTransfer(AccountNum1, AccountNum2, amount);
				System.out.println("Fund Transfer Successfully done!!!");
				break;
				
			case 7:
				System.out.println("Your Account Details are: " +customerservice.accountdetails());
				break;
			case 8:
				System.out.println("Enter A/c no to print all the transactions:");
				int accountno = sc.nextInt();
				System.out.println("Your transaction details are: "+customerservice.printTransactions(accountno));
				break;
			case 9:
				System.out.println("Terminated!!!!!");
				System.exit(0);
				default:
					System.out.println("Wrong Choisee!!!");
					
				
	}

}
}
}